#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#include "horrocrux.h"
#define CONVENCION_CURAS 'P'
#define CONVENCION_SALIDA 'S'
#define CONVENCION_OBJETO 'O'
#define CONVENCION_BASILISCO 'B'
#define CONVENCION_DUENDE 'G'
#define CONVENCION_DIARIO 'D'
#define CONVENCION_ANILLO 'A'
#define CONVENCION_GUARDAPELO 'L'
#define CONVENCION_COPA 'C'
#define CONVENCION_DOLORES 'U'
#define CONVENCION_ESPADA 'E'
#define CONVENCION_COLMILLOS 'F'
#define CONVENCION_ARRIBA 'w'
#define CONVENCION_ABAJO 's'
#define CONVENCION_DERECHA 'd'
#define CONVENCION_IZQUIERDA 'a'
#define CONVENCION_JUGADOR 'J'
#define TURNOS_MAXIMOS 75

bool es_la_misma_posicion_2(coordenadas_t coor1, coordenadas_t coor2){
    return (coor1.fila==coor2.fila && coor1.columna==coor2.columna);
}

void caracteristicas_del_usuario(juego_t juego){
    if (es_la_misma_posicion_2(juego.niveles[0].entrada,juego.jugador.posicion) && juego.nivel_actual==1)
        printf("En este juego vos(%c) tenes que romper el horrocrux de cada nivel, e ir a la salida(%c) para seguir avanzando.\nPodes moverte por el mapa usando %c, %c, %c, %c(arriba, abajo, izquierda, derecha respectivamente) y podes agarrar varios objetos y guardarlos tu mochila.\nMetele pata porque solo tenes %d turnos para ganar.\nEn este caso el horrocrux es el anillo(%c), pero además hay curas(%c) por todo el mapa, ¿Para qué las querrias si estas perfectamente sano?\nSiempre podes volver a este mismo lugar para ver la presentación del nivel",CONVENCION_JUGADOR, CONVENCION_SALIDA, CONVENCION_ARRIBA, CONVENCION_ABAJO, CONVENCION_IZQUIERDA, CONVENCION_DERECHA, TURNOS_MAXIMOS, CONVENCION_ANILLO, CONVENCION_CURAS);
    if (es_la_misma_posicion_2(juego.niveles[1].entrada,juego.jugador.posicion)&& juego.nivel_actual==2)
        printf("¡Cuidado un Basilisco(%c) suelto! Es como un laser, si te toca te quema.\nAl parecer se le cayeron algunos colimillos (%c) o alguien se los saco con esa espada (%c)\nPor eliminación supongo que ese librito(%c) de ahi es el horrocrux.", CONVENCION_BASILISCO, CONVENCION_COLMILLOS, CONVENCION_ESPADA, CONVENCION_DIARIO);
    if (es_la_misma_posicion_2(juego.niveles[2].entrada,juego.jugador.posicion)&& juego.nivel_actual==3)
        printf("Ese duende(%c) de nuevo, ni te gastes en tratar de matarlo solo te va a ser perder el tiempo, ignoralo y anda rápido a romper la copa(%c) ¿Tenes algo para romperla cierto?", CONVENCION_DUENDE, CONVENCION_COPA);
    if (es_la_misma_posicion_2(juego.niveles[3].entrada,juego.jugador.posicion)&& juego.nivel_actual==4)
        printf("Dolores Umbridge(%c), no creo que ella pueda matarte pero hara lo posible por hacerlo y que no puedas romper el guardapelo(%c)", CONVENCION_DOLORES, CONVENCION_GUARDAPELO);
    if (es_la_misma_posicion_2(juego.niveles[1].horrocrux.posicion,juego.jugador.posicion) && !juego.niveles[1].horrocrux_destruido && juego.nivel_actual==2)
        printf("Vi en una película que se podían destruir diarios solo con colmillos de Basilisco, si lo vi en una película debe ser verdad.");
    if (es_la_misma_posicion_2(juego.niveles[2].horrocrux.posicion,juego.jugador.posicion) && !juego.niveles[2].horrocrux_destruido && juego.nivel_actual==3)
        printf("Ésta copa le pertenecio a la misma Helga Hufflepuff, no va a ser fácil de romper, y tampoco hay nada más aqui. En estos momentos solo se puede reir.");
    if (es_la_misma_posicion_2(juego.niveles[3].horrocrux.posicion,juego.jugador.posicion) && !juego.niveles[3].horrocrux_destruido && juego.nivel_actual==4)
        printf("Me parece que tendrías que agarrar todos los objetos de todos los niveles, por si las moscas.");
    printf("\n\nTe quedan %i turnos\n",juego.jugador.turnos_restantes);
    if (juego.jugador.envenenado)
        printf("¡Estas envenenado! Creo que podias curarte tirandote al piso y rodando.\n Turnos envenenado %i\n",juego.jugador.turnos_envenenado);
    printf("Mochila: ");
    for (int i=0; i<juego.jugador.cantidad_items;i++)
        printf("- %c ",juego.jugador.items[i].codigo);
    printf("-\n");
}

void mensaje_gane(){
    printf("Rompiste los %d horrocruxes y Harry podrá matar al Señor Oscuro tranquilo, confia en mi no va a revivir.\n", CANTIDAD_NIVELES);
}

void mensaje_perdi(){
    printf("¡2 AÑOS DE TRABAJO ARRUINO!\n");
}

int main(){
    srand((unsigned)clock());
    juego_t juego;
    char movimiento;
    char escenario[MAX_FILAS][MAX_COLUMNAS];
    inicializar_juego(&juego);
    actualizar_escenario(juego, escenario);
    mostrar_escenario(escenario, juego.niveles[juego.nivel_actual-1].filas, juego.niveles[juego.nivel_actual-1].columnas);
    caracteristicas_del_usuario(juego);
    do{    
        do{
            printf("Ingrese movimiento\n");
            scanf( " %c", &movimiento);
        }while(!puede_moverse_jugador(movimiento,juego));   
    mover_jugador(&juego,movimiento);
    actualizar_escenario(juego, escenario);
    mover_guardian(&juego);
    actualizar_escenario(juego, escenario);
    mostrar_escenario(escenario, juego.niveles[juego.nivel_actual-1].filas, juego.niveles[juego.nivel_actual-1].columnas);
    caracteristicas_del_usuario(juego);
    }while (estado_juego(juego) == 0);
    if(juego.estado ==1)
        mensaje_gane();
    if(juego.estado ==-1)
        mensaje_perdi();
    return 0;

}



