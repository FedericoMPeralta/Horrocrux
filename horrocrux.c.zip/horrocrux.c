#include <stdlib.h>
#include "horrocrux.h"
#include <stdio.h>
#define MAX_PERIMETRO 70
#define FILA_DUENDE 2
#define FILA_MEDIDA_CAMINO_DOLORES 3
#define COLUMNA_MEDIDA_CAMINO_DOLORES 3
#define CONVENCION_NADA 'N'
#define CONVENCION_ENTRADA 'T'
#define CONVENCION_SALIDA 'S'
#define CONVENCION_OBJETO 'O'
#define CONVENCION_BASILISCO 'B'
#define CONVENCION_DUENDE 'G'
#define FILA_MEDIDA_CAMINO_BASILISCO 3
#define COLUMNA_MEDIDA_CAMINO_BASILISCO 5
#define FILA_ESQUINA_CAMINO_BASILISCO 2
#define COLUMNA_ESQUINA_CAMINO_BASILISCO 1
#define CONVENCION_CAMINO_GUARDIAN 'R'
#define CONVENCION_DIARIO 'D'
#define CONVENCION_ANILLO 'A'
#define CONVENCION_GUARDAPELO 'L'
#define CONVENCION_COPA 'C'
#define CONVENCION_DOLORES 'U'
#define FILA_ENTRADA_NIVEL_1 4
#define COLUMNA_ENTRADA_NIVEL_1 2
#define FILA_ENTRADA_NIVEL_2 6
#define COLUMNA_ENTRADA_NIVEL_2 3
#define FILA_ENTRADA_NIVEL_3 4
#define COLUMNA_ENTRADA_NIVEL_3 2
#define FILA_ENTRADA_NIVEL_4 6
#define COLUMNA_ENTRADA_NIVEL_4 3
#define FILA_SALIDA_NIVEL_1 0
#define COLUMNA_SALIDA_NIVEL_1 2
#define FILA_SALIDA_NIVEL_2 0
#define COLUMNA_SALIDA_NIVEL_2 3
#define FILA_SALIDA_NIVEL_3 0
#define COLUMNA_SALIDA_NIVEL_3 2
#define FILA_SALIDA_NIVEL_4 0
#define COLUMNA_SALIDA_NIVEL_4 3
#define FILAS_NIVEL_1 5
#define COLUMNAS_NIVEL_1 5
#define FILAS_NIVEL_2 7
#define COLUMNAS_NIVEL_2 7
#define FILAS_NIVEL_3 5
#define COLUMNAS_NIVEL_3 5
#define FILAS_NIVEL_4 7
#define COLUMNAS_NIVEL_4 7
#define CONVENCION_ESPADA 'E'
#define CONVENCION_COLMILLOS 'F'
#define CONVENCION_ARRIBA 'w'
#define CONVENCION_ABAJO 's'
#define CONVENCION_DERECHA 'd'
#define CONVENCION_IZQUIERDA 'a'
#define CANT_CURAS_NIVEL_1 3
#define CONVENCION_CURAS 'P'
#define CANT_COLMILLOS_NIVEL_2 6
#define TURNOS_MAXIMOS 75
#define CONVENCION_JUGADOR 'J'
#define TURNOS_MAXIMOS_ENVENEDADO 10
#define CONVENCION_HORROCRUX 'H'
#define TURNOS_PERDIDOS_DUENDE 7
#define TURNOS_PERDIDOS_DOLORES 10
#define CANT_COLMILLOS_NECESARIOS_NIVEL_2 1
#define CANT_COLMILLOS_NECESARIOS_NIVEL_3 2
#define CANT_COLMILLOS_NECESARIOS_NIVEL_4 1
#define CANT_CURAS_NECESARIAS_NIVEL_1 1
#define CONVENCION_IZQUIERDA_DUENDE 'i'
#define CONVENCION_DERECHA_DUENDE 'd'
#define FILA_INICIAL_DUENDE 2
#define COLUMNA_INICIAL_DUENDE 2
#define FILA_INICIAL_BASILISCO 3 
#define COLUMNA_INICIAL_BASILISCO 5

/* Devuelve todas las posiciones del borde de un rectangulo.
 * Precondiciones: Se ingresa la esquina superior derecha del rectangulo
 * y las medidas del rectangulo, siempre dentro de los limites dictados
 * por la matriz de su respectivo nivel.
 * Postcondiciones: Se devuelve la matriz que representa el borde del
 * rectangulo y la cantidad de posiciones.
 */
void borde_rectangulo(coordenadas_t posiciones[MAX_PERIMETRO], unsigned int*tope,coordenadas_t esquina,coordenadas_t medida_rectangulo){
    unsigned int i=esquina.fila;
    unsigned int j=esquina.columna;
    (*tope)=0;
    for (;i<esquina.fila+medida_rectangulo.fila-1;i++){
        posiciones[*tope].fila=i;
        posiciones[*tope].columna=j;
        (*tope)++;
    }
    for(;j<esquina.columna+medida_rectangulo.columna-1;j++){
        posiciones[*tope].fila=i;
        posiciones[*tope].columna=j;
        (*tope)++;
    }
    for (;i>esquina.fila;i--){
        posiciones[*tope].fila=i;
        posiciones[*tope].columna=j;
        (*tope)++;
    }
    for(;j>esquina.columna;j--) {
        posiciones[*tope].fila=i;
        posiciones[*tope].columna=j;
        (*tope)++;
    }
}
/* Devuelve todas las posiciones del camino que recorre el duende.
 * Precondiciones: La fila por donde se mueve el duende esta dentro de los limites dictados
 * por la matriz de su respectivo nivel.
 * Postcondiciones: Se devuelve la matriz que representa el camino que recorre el duende
 * y la cantidad de posiciones.
 */

void camino_duende(coordenadas_t posiciones[MAX_PERIMETRO],unsigned int* tope,nivel_t nivel){
    unsigned int i=FILA_DUENDE;
    (*tope)=0;
    for (unsigned int j=0;j<nivel.filas;j++){
        posiciones[(*tope)].fila=i;
        posiciones[(*tope)].columna=j;
        (*tope)++;
    }
}

/* Devuelve todas las posiciones donde el guardapelo no puede ir debido a que dolores
 * gira alrededor de este y no puede chocar con la salida, la entrada ni el borde del nivel.
 * Precondiciones: Las filas y columnas del nivel se inicializaron, asi como la 
 * posicion de la entrada, salida en el mismo nivel.
 * Postcondiciones: Se devuelve la matriz que representa las posiciones ya dichas
 * y la cantidad de posiciones.
 */

void posiciones_imposibles_camino_dolores(coordenadas_t posiciones[MAX_PERIMETRO],unsigned int* tope,nivel_t nivel){
    (*tope)=0;
    coordenadas_t medida;
    coordenadas_t esquina;
    esquina.fila=0;
    esquina.columna=0;
    medida.fila=nivel.filas;
    medida.columna=nivel.columnas;
    borde_rectangulo(posiciones, &(*tope),esquina,medida);
    nivel.entrada.fila -= 1;
    nivel.entrada.columna -= 1;
    nivel.salida.fila += 1;
    nivel.salida.columna -= 1;
    for (int i=0;i<3;i++){
        posiciones[(*tope)]=nivel.entrada;
        nivel.entrada.columna ++;
        (*tope)++;
    }
    for (int i=0;i<3;i++){
    posiciones[(*tope)]=nivel.salida;
    nivel.salida.columna ++;
    (*tope)++;
    }
}
/* Devuelve todas las posiciones del camino que recorre el basilisco.
 * Precondicones: La posiciones de la esquina y las medidas del rectangulo que recorre 
 * el basilisco estan dentro de los limites dictados por la matriz de su respectivo nivel.
 * Postcondiciones: Se devuelve la matriz que representa el camino que recorre el basilisco
 * y la cantidad de posiciones.
 */
void camino_basilisco(coordenadas_t posiciones[MAX_PERIMETRO],unsigned int*tope){
    (*tope)=0;
    coordenadas_t medida;
    coordenadas_t esquina;
    medida.fila=FILA_MEDIDA_CAMINO_BASILISCO;
    medida.columna=COLUMNA_MEDIDA_CAMINO_BASILISCO;
    esquina.fila=FILA_ESQUINA_CAMINO_BASILISCO;
    esquina.columna=COLUMNA_ESQUINA_CAMINO_BASILISCO;
    borde_rectangulo(posiciones,&(*tope),esquina,medida);

}
/* Valida si 2 coordeandas son iguales
 * Precondiciones:
 * Postcondiciones: Devuelve si las coordenadas son iguales
 */

bool es_la_misma_posicion(coordenadas_t coor1, coordenadas_t coor2){
    return (coor1.fila==coor2.fila && coor1.columna==coor2.columna);
}

/* Valida si la coordenada molesta al camino del guardian.
 * Precondiciones: El tope debe ser la cantidad de posiciones.
 * Postcondiciones: Actualiza un que_es si la coordeanda puede llegar
 * a evitar que el camino del guardian se cree apropiadamente.
 */

void molesta_al_camino_guardian(coordenadas_t posiciones[MAX_PERIMETRO],coordenadas_t coordenada,unsigned int tope,char* que_es){
    for (int i=0; i<tope;i++){
        if (es_la_misma_posicion(posiciones[i],coordenada))
            (*que_es) =CONVENCION_CAMINO_GUARDIAN;
    }
}

/* Devuelve las posiciones donde puede ir el diario.
 * Precondiciones: Las mediads del camino del basilisco deben por lo menos de 3v3.
 * Postcondiciones: Se devuelve la matriz que representa las posiciones de adentro del camino del basilisco y la cantidad de posiciones.
 */

void posiciones_posibles_diario(coordenadas_t posiciones[MAX_PERIMETRO],unsigned int* tope){
    unsigned int i=0;
    unsigned int j=0;
    for(;i<FILA_MEDIDA_CAMINO_BASILISCO-2;i++){
        for(;j<COLUMNA_MEDIDA_CAMINO_BASILISCO-2;j++){
            posiciones[(*tope)].fila=FILA_ESQUINA_CAMINO_BASILISCO+i+1;
            posiciones[(*tope)].columna=COLUMNA_ESQUINA_CAMINO_BASILISCO+j+1;
            (*tope)++;
        }
    }
}

/* Valida que no haya algo en la posicion dada.
 * Precondicones: Se inicializaron el codigo y la posicion del guardian
 * del nivel (expetuando la posicion si esta dolores), asi como la cantidad
 * de objetos, la posicion de la salida, y la entrada del nivel.
 * Postcondiciones: Se devolvera un caracter que puede representar: nada,
 * objeto, camino del guardian, entrada, salida y horrocrux.
 */

char que_hay (coordenadas_t coordenadas,nivel_t nivel){
    coordenadas_t posiciones[MAX_PERIMETRO];
    char que_es =  CONVENCION_NADA;
    unsigned int tope=0;
    switch (nivel.guardian.codigo){
        case CONVENCION_BASILISCO:
            camino_basilisco(posiciones,&tope);
            posiciones_posibles_diario(posiciones,&tope);
            molesta_al_camino_guardian(posiciones,coordenadas,tope,&que_es);
            break;
        case CONVENCION_DUENDE:
            camino_duende(posiciones,&tope,nivel);
            molesta_al_camino_guardian(posiciones,coordenadas,tope,&que_es);
            break;
        case CONVENCION_DOLORES:
            posiciones_imposibles_camino_dolores(posiciones,&tope,nivel);
            molesta_al_camino_guardian(posiciones,coordenadas,tope,&que_es);
            break;
    }
    if (es_la_misma_posicion(nivel.entrada,coordenadas))
        que_es = CONVENCION_ENTRADA;
    if(es_la_misma_posicion(nivel.salida,coordenadas))
        que_es = CONVENCION_SALIDA;
    if(es_la_misma_posicion(nivel.horrocrux.posicion,coordenadas))
        que_es=CONVENCION_HORROCRUX;
    for (int i=0; i<nivel.cantidad_objetos; i++){
        if (es_la_misma_posicion(nivel.objetos[i].posicion,coordenadas))
             que_es= CONVENCION_OBJETO;
    }
    return que_es;
}

/* Devuelve un numero aleatorio.
 * Precondiciones: tope no es 0.
 * Postcondiciones: El numero esta entre 0 y tope-1.
 */
unsigned int numero_aleatorio(unsigned int tope){
    return ((unsigned int)rand() % (tope));
}

coordenadas_t posicion_aleatoria(unsigned int filas, unsigned int columnas){
    coordenadas_t coor;
    coor.fila = numero_aleatorio(filas);
    coor.columna = numero_aleatorio(columnas);
    return coor;
}

/* Devuelve una posicion.
 * Precondiciones: Mismas precondiciones que la funcion "que_hay".
 * Postcondiciones:  La posicion no esta ocupada, y el guardian no puede
 * pasar por esa posicion.
 */

coordenadas_t posicion_posible(nivel_t nivel){
    coordenadas_t coordenadas;
    do{
        coordenadas= posicion_aleatoria(nivel.filas,nivel.columnas);
    }while(que_hay(coordenadas,nivel)!=CONVENCION_NADA);
    return coordenadas;
}
/* Inicializa el nivel 1
 * Precondiciones:
 * Postcondiciones: Devuelve el nivel 1 listo para ser jugado.
 */

void inicializar_nivel_1(nivel_t *nivel){
    (*nivel).numero=1 ;
    (*nivel).horrocrux_destruido=false;
    (*nivel).horrocrux.codigo = CONVENCION_ANILLO;
    (*nivel).tiene_guardian = false;
    (*nivel).entrada.fila= FILA_ENTRADA_NIVEL_1;
    (*nivel).entrada.columna= COLUMNA_ENTRADA_NIVEL_1;
    (*nivel).salida.fila = FILA_SALIDA_NIVEL_1;
    (*nivel).salida.columna = COLUMNA_SALIDA_NIVEL_1;
    (*nivel).filas =FILAS_NIVEL_1;
    (*nivel).columnas=COLUMNAS_NIVEL_1;
    (*nivel).cantidad_objetos = 0;
    (*nivel).horrocrux.posicion = posicion_posible(*nivel);
    for (int i =0;i< CANT_CURAS_NIVEL_1;i++){
        (*nivel).objetos[i].codigo = CONVENCION_CURAS;
        (*nivel).objetos[i].posicion=posicion_posible(*nivel);
        (*nivel).cantidad_objetos++;
    }
}



/* Inicializa el nivel 2
 * Precondiciones:
 * Postcondiciones: Devuelve el nivel 2 listo para ser jugado.
 */

void inicializar_nivel_2(nivel_t *nivel){
    int i=0;
    unsigned int numero_random;
    unsigned int tope=0;
    coordenadas_t posiciones[MAX_PERIMETRO];
    (*nivel).numero=2;
    (*nivel).horrocrux_destruido=false;
    (*nivel).horrocrux.codigo = CONVENCION_DIARIO;
    (*nivel).tiene_guardian = true;
    (*nivel).guardian.posicion.fila = FILA_INICIAL_BASILISCO;
    (*nivel).guardian.posicion.columna = COLUMNA_INICIAL_BASILISCO;
    (*nivel).guardian.codigo = CONVENCION_BASILISCO;
    (*nivel).basilisco_destruido= false;
    (*nivel).entrada.fila= FILA_ENTRADA_NIVEL_2;
    (*nivel).entrada.columna= COLUMNA_ENTRADA_NIVEL_2;
    (*nivel).salida.fila = FILA_SALIDA_NIVEL_2;
    (*nivel).salida.columna = COLUMNA_SALIDA_NIVEL_2;
    (*nivel).filas =FILAS_NIVEL_2;
    (*nivel).columnas=COLUMNAS_NIVEL_2;
    (*nivel).cantidad_objetos = 0;
    posiciones_posibles_diario(posiciones,&tope);
    numero_random=numero_aleatorio(tope);
    (*nivel).horrocrux.posicion = posiciones[numero_random];
    for (;i< CANT_COLMILLOS_NIVEL_2;i++){
        (*nivel).objetos[i].codigo = CONVENCION_COLMILLOS;
        (*nivel).objetos[i].posicion=posicion_posible(*nivel);
        (*nivel).cantidad_objetos++;
    }
    (*nivel).objetos[i].codigo=CONVENCION_ESPADA;
    (*nivel).objetos[i].posicion=posicion_posible(*nivel);
    (*nivel).cantidad_objetos++;
}
/* Inicializa el nivel 3
 * Precondiciones:
 * Postcondiciones: Devuelve el nivel 3 listo para ser jugado.
 */

void inicializar_nivel_3(nivel_t* nivel){
    (*nivel).numero=3;
    (*nivel).cantidad_objetos = 0;
    (*nivel).direccion_duende = CONVENCION_IZQUIERDA_DUENDE;
    (*nivel).horrocrux_destruido=false;
    (*nivel).horrocrux.codigo =CONVENCION_COPA;
    (*nivel).tiene_guardian = true;
    (*nivel).guardian.posicion.fila = FILA_INICIAL_DUENDE;
    (*nivel).guardian.posicion.columna = COLUMNA_INICIAL_DUENDE;
    (*nivel).guardian.codigo = CONVENCION_DUENDE;
    (*nivel).entrada.fila= FILA_ENTRADA_NIVEL_3;
    (*nivel).entrada.columna= COLUMNA_ENTRADA_NIVEL_3;
    (*nivel).salida.fila = FILA_SALIDA_NIVEL_3;
    (*nivel).salida.columna = COLUMNA_SALIDA_NIVEL_3;
    (*nivel).filas =FILAS_NIVEL_3;
    (*nivel).columnas=COLUMNAS_NIVEL_3;
    (*nivel).horrocrux.posicion = posicion_posible(*nivel);
    
}
/* Devuelve todas las posiciones del camino que recorre dolores.
 * Precondicones: Las medidas del rectangulo que recorre dolores estan dentro
 * de los limites dictados por la matriz de su respectivo nivel, y la posicion del horrocrux
 * de su respectivo fue inicializada.
 * Postcondiciones: Se devuelve la matriz que representa el camino que recorre dolores
 * y la cantidad de posiciones.
 */

void camino_dolores(coordenadas_t posiciones[MAX_PERIMETRO],unsigned int* tope,nivel_t nivel){
    (*tope)=0;
    coordenadas_t medida;
    coordenadas_t esquina;
    medida.fila=FILA_MEDIDA_CAMINO_DOLORES;
    medida.columna=COLUMNA_MEDIDA_CAMINO_DOLORES;
    esquina.fila = nivel.horrocrux.posicion.fila -1;
    esquina.columna = nivel.horrocrux.posicion.columna -1;
    borde_rectangulo(posiciones,&(*tope),esquina,medida);
}

/* Inicializa el nivel 4
 * Precondiciones:
 * Postcondiciones: Devuelve el nivel 4 listo para ser jugado.
 */

void inicializar_nivel_4(nivel_t* nivel){
    (*nivel).numero=4;
    (*nivel).entrada.fila= FILA_ENTRADA_NIVEL_4;
    (*nivel).entrada.columna= COLUMNA_ENTRADA_NIVEL_4;
    (*nivel).salida.fila = FILA_SALIDA_NIVEL_4;
    (*nivel).salida.columna = COLUMNA_SALIDA_NIVEL_4;
    (*nivel).guardian.codigo = CONVENCION_DOLORES;
    (*nivel).filas =FILAS_NIVEL_4;
    (*nivel).columnas=COLUMNAS_NIVEL_4;
    (*nivel).cantidad_objetos = 0;
    (*nivel).horrocrux_destruido=false;
    unsigned int tope=0;
    unsigned int numero_random;
    coordenadas_t posiciones[MAX_PERIMETRO];
    (*nivel).horrocrux.codigo = CONVENCION_GUARDAPELO;
    (*nivel).tiene_guardian = true;
    (*nivel).horrocrux.posicion = posicion_posible(*nivel);
    camino_dolores(posiciones,&tope,*nivel);
    numero_random=numero_aleatorio(tope);
    (*nivel).guardian.posicion= posiciones[numero_random];
  
 
}
/* Inicializa el jugador.
 * Precondiciones: La posicion de la entrada del nivel 1 fue inicializada.
 * Postcondiciones: Devuelve el jugador listo para comenzar el juego.
 */

void inicializar_jugador(juego_t* juego){
    (*juego).jugador.posicion =(*juego).niveles[0].entrada;
    (*juego).jugador.cantidad_items=0;
    (*juego).jugador.envenenado= false;
    (*juego).jugador.turnos_envenenado=0;
    (*juego).jugador.turnos_restantes= TURNOS_MAXIMOS;
}

void inicializar_juego(juego_t *juego){
    (*juego).estado = 0;
    (*juego).nivel_actual = 1;
    for (unsigned int v=0; v<CANTIDAD_NIVELES; v++){
        switch(v){
        case 0:inicializar_nivel_1(&(*juego).niveles[v]);
            break;
        case 1:inicializar_nivel_2(&(*juego).niveles[v]);
            break;
        case 2:inicializar_nivel_3(&(*juego).niveles[v]);
            break;
        case 3:inicializar_nivel_4(&(*juego).niveles[v]);
            break;
        }
    }
     inicializar_jugador(juego);
}
/*
 * Actualiza la matriz que representa visualmente el estado del juego en el nivel actual.
 * Precondiciones: El juego está en un estado válido.
 * Postcondiciones: Se posiciona el horrocrux.
 */

void actualizar_horrocrux(nivel_t nivel, char escenario[MAX_FILAS][MAX_COLUMNAS]){
    escenario[nivel.horrocrux.posicion.fila][nivel.horrocrux.posicion.columna] = nivel.horrocrux.codigo;
}
/*
 * Actualiza la matriz que representa visualmente el estado del juego en el nivel actual.
 * Precondiciones: El juego está en un estado válido.
 * Postcondiciones: Se posiciona el guaridan.
 */

void actualizar_guardian(nivel_t nivel, char escenario[MAX_FILAS][MAX_COLUMNAS]){
    if (nivel.guardian.codigo==CONVENCION_BASILISCO && nivel.basilisco_destruido)
        return;
    escenario[nivel.guardian.posicion.fila][nivel.guardian.posicion.columna] =nivel.guardian.codigo;
}


/*
 * Actualiza la matriz que representa visualmente el estado del juego en el nivel actual.
 * Precondiciones: El juego está en un estado válido.
 * Postcondiciones: Se posiciona la salida.
 */

void actualizar_salida(nivel_t nivel, char escenario[MAX_FILAS][MAX_COLUMNAS]){
    escenario[nivel.salida.fila][nivel.salida.columna] = CONVENCION_SALIDA;
}
/*
 * Actualiza la matriz que representa visualmente el estado del juego en el nivel actual.
 * Precondiciones: El juego está en un estado válido.
 * Postcondiciones: Se posicionan los objetos.
 */

void actualizar_objetos(nivel_t nivel, char escenario[MAX_FILAS][MAX_COLUMNAS]){
for (int i =0;i< nivel.cantidad_objetos;i++)
    escenario[nivel.objetos[i].posicion.fila][nivel.objetos[i].posicion.columna]=  nivel.objetos[i].codigo;
}
/*
 * Actualiza la matriz que representa visualmente el estado del juego en el nivel actual.
 * Precondiciones: El juego está en un estado válido.
 * Postcondiciones: Se posiciona el jugador.
 */

void actualizar_jugador(coordenadas_t posicion,char escenario[MAX_FILAS][MAX_COLUMNAS]){
    escenario[posicion.fila][posicion.columna] =  CONVENCION_JUGADOR;    
}
/* Inicializa la matriz que representa visualmente el estao del juego en el nivel actual. 
 * Precondiciones: El juego está en un estado válido.
 * Postcondiciones: Todas las posiciones quedan con un espacio vacio.
 */

void inicializar_escenario(char escenario[MAX_FILAS][MAX_COLUMNAS], nivel_t nivel){
    for (int i=0; i<nivel.filas;i++)
        for (int j=0;j<nivel.columnas;j++)
                escenario[i][j]=' ';
}



void actualizar_escenario(juego_t juego, char escenario[MAX_FILAS][MAX_COLUMNAS]){
    inicializar_escenario(escenario,juego.niveles[juego.nivel_actual - 1]);
    if (!juego.niveles[juego.nivel_actual- 1].horrocrux_destruido)
        actualizar_horrocrux(juego.niveles[juego.nivel_actual- 1], escenario);
    if (juego.niveles[juego.nivel_actual- 1].tiene_guardian)
        actualizar_guardian(juego.niveles[juego.nivel_actual- 1], escenario);
    actualizar_objetos(juego.niveles[juego.nivel_actual- 1], escenario);
    actualizar_salida(juego.niveles[juego.nivel_actual- 1],escenario);
    actualizar_jugador(juego.jugador.posicion,escenario);
}
/* Se actualiza el juego segun el ganador de la pelea!
 * Precondiciones:
 * Postcondiciones: El basilisco es destruido si el jugador tiene la espada
 * y el jugador pierde si no la tiene.
 */

void pelea_basilisco(juego_t* juego){
    for (int i=0; i<(*juego).jugador.cantidad_items;i++)
        if((*juego).jugador.items[i].codigo==CONVENCION_ESPADA){
            (*juego).niveles[(*juego).nivel_actual- 1].basilisco_destruido=true;
            return;
        }
    (*juego).estado= -1;
}    
/* Se actualiza el juego debido a la interaccion con el guardian.
 * Precondiciones: El nivel tiene un guardian.
 * Postcondiciones: Si el jugador esta en la misma posicion que el guardian
 * se actualiza el juego dependiendo que guardian sea.
 */

void interaccion_guardian(juego_t* juego){
    if (es_la_misma_posicion((*juego).jugador.posicion,(*juego).niveles[(*juego).nivel_actual- 1].guardian.posicion)){
        switch((*juego).niveles[(*juego).nivel_actual- 1].guardian.codigo){
        case CONVENCION_BASILISCO:
            if  (!(*juego).niveles[(*juego).nivel_actual- 1].basilisco_destruido){
                pelea_basilisco(&(*juego));        
            }
            break;
        case CONVENCION_DUENDE:
            if ((*juego).jugador.turnos_restantes>=TURNOS_PERDIDOS_DUENDE)
                    (*juego).jugador.turnos_restantes-=TURNOS_PERDIDOS_DUENDE;
            else
                    (*juego).jugador.turnos_restantes=0;
            break;
        case CONVENCION_DOLORES:
            if ((*juego).jugador.turnos_restantes>=TURNOS_PERDIDOS_DOLORES)
                    (*juego).jugador.turnos_restantes-=TURNOS_PERDIDOS_DOLORES;
            else
                    (*juego).jugador.turnos_restantes=0;
            break;
        }
    }
}
/* Devuelve la posicion del objeto.
 * Precondiciones: Hay un objeto en la misma posicion que el jugador.
 * Postcondiciones: la posicion en la matriz de objetos.
 */

int posicion_objeto_a_agarrar (juego_t juego){ 
    int posicion_objeto=-1;
    int i=0;
    while (posicion_objeto==-1){
        if (es_la_misma_posicion(juego.niveles[juego.nivel_actual- 1].objetos[i].posicion,juego.jugador.posicion))
            posicion_objeto=i;
        i++;
    }
     return posicion_objeto;
}
/* Se elimina un elemento
 * Precondiciones: La posicion del elemento es valida y el tope no es 0.
 * Postcondiciones: Se elimina el elemento en su matriz y se baja el tope en 1.
 */

void eliminar_elemento(int posicion_elemento, elemento_t elementos[MAX_ITEMS], unsigned int* tope){
    (*tope)--;
    for(int j=posicion_elemento;j<(*tope);j++)
        elementos[j]=elementos[j+1];
}
/* El jugador agrega el objeto a su mochila.
 * Precondiciones: El objeto sigue en el piso.
 * Postcondiciones: El objeto se agrego a los items del jugador y la 
 * cantidad de items aumento.
 */

void agregar_item(juego_t* juego,int posicion_objeto){
    (*juego).jugador.items[(*juego).jugador.cantidad_items].codigo=(*juego).niveles[(*juego).nivel_actual- 1].objetos[posicion_objeto].codigo;
    (*juego).jugador.cantidad_items++;
}
/* Se agarra el objeto.
 * Precondiciones: El jugador esta en la misma posicion que un objeto.
 * Postcondiciones: Si el item es una cura el jugador se cura y no se agrega la cura,
 * sino se elimina el objeto del piso y se agrega a los items del jugador.
 */

void agarrar_objeto(juego_t* juego){
    int posicion_objeto;
    posicion_objeto = posicion_objeto_a_agarrar((*juego));
    if ((*juego).niveles[(*juego).nivel_actual- 1].objetos[posicion_objeto].codigo== CONVENCION_CURAS){
        if ((*juego).jugador.envenenado)
            (*juego).jugador.envenenado=false;
        else
            agregar_item(&(*juego),posicion_objeto);
    }else
        agregar_item(&(*juego),posicion_objeto);
    eliminar_elemento(posicion_objeto,(*juego).niveles[(*juego).nivel_actual- 1].objetos,&(*juego).niveles[(*juego).nivel_actual- 1].cantidad_objetos);
}

/* Devuelve la posicion de un tipo de item buscado.
 * Precondiciones: Hay un item que tiene el mismo tipo de item al buscado.
 * Postcondiciones: La posicion es la posicion del item en items.
 */

int posicion_item (elemento_t items[MAX_ITEMS], char codigo){
    int posicion=-1;
    int i=0;
    while (posicion==-1){
        if (items[i].codigo==codigo)
            posicion=i;
        i++;
    }
     return posicion;
}
      
/* Cuenta cuantos items tienen el mismo tipo.
 * Precondiciones: 
 * Postcondicones: Devuelve cuantos items tienen el mismo tipo de item al buscado.
 */

int contar_items_segun_tipo (juego_t juego, char codigo){
    int i=0;
    int contador=0;
    for (;i<juego.jugador.cantidad_items;i++)
        if (juego.jugador.items[i].codigo==codigo)
            contador++;
    return contador;
}

/* Usa una cantidad de items.
 * Precondiciones: Por lo menos hay la misma cantidad de items con el tipo de item
 * a buscar, que veces se quiere usar los items.
 * Postcondiciones: Se eliminan tantos items del tipo de item pedido como veces se pidio.
 */

void usar_items(jugador_t* jugador, char item,int veces){
    int posicion;
    for(int i=0;i<veces;i++){
        posicion=posicion_item((*jugador).items,item);
        eliminar_elemento(posicion,(*jugador).items,&(*jugador).cantidad_items);
    }
}
/* Se intenta romper el horrocrux.
 * Precondiones: El horrocrux del respectivo nivel no ha sido destruido.
 * Postcondiciones: Si cumplen las condiciones, se rompe el horrocrux y se
 * actualiza el juego si es necesario.
 */

void intentar_romper_horrocrux(juego_t* juego){
    switch ((*juego).niveles[(*juego).nivel_actual- 1].horrocrux.codigo){
        case CONVENCION_ANILLO: if (contar_items_segun_tipo((*juego),CONVENCION_CURAS)>0)
            usar_items(&(*juego).jugador,CONVENCION_CURAS,CANT_CURAS_NECESARIAS_NIVEL_1);
            else
                (*juego).jugador.envenenado=true;
            break;
        case CONVENCION_DIARIO: if (contar_items_segun_tipo((*juego),CONVENCION_COLMILLOS)>=CANT_COLMILLOS_NECESARIOS_NIVEL_2){
            usar_items(&(*juego).jugador,CONVENCION_COLMILLOS,CANT_COLMILLOS_NECESARIOS_NIVEL_2);
                break;
            }else
                return;
        case CONVENCION_COPA:if (contar_items_segun_tipo((*juego),CONVENCION_ESPADA)>0)
                break;
            else if (contar_items_segun_tipo((*juego),CONVENCION_COLMILLOS)>=CANT_COLMILLOS_NECESARIOS_NIVEL_3){
                usar_items(&(*juego).jugador,CONVENCION_COLMILLOS,CANT_COLMILLOS_NECESARIOS_NIVEL_3);
            break;
            }else
                return;
         case CONVENCION_GUARDAPELO: if (contar_items_segun_tipo((*juego),CONVENCION_ESPADA)>0)
                break;
            else if (contar_items_segun_tipo((*juego),CONVENCION_COLMILLOS)>=CANT_COLMILLOS_NECESARIOS_NIVEL_4){
                usar_items(&(*juego).jugador,CONVENCION_COLMILLOS,CANT_COLMILLOS_NECESARIOS_NIVEL_4);
            break;
            }else
                return;
    }
    (*juego).niveles[(*juego).nivel_actual- 1].horrocrux_destruido=true;
}
            
        
/* Actualiza la posicion del jugador en el nivel actual.
 * Precondiciones: El jugador tiene por lo menos 1 movimiento restante
 * y el movimiento es valido.
 * Postcondiciones: El jugador piede 1 turno y,si este esta envenenado,
 * pasa un turno mas enveneneado.
 */

void movimiento_jugador(jugador_t* jugador, char direccion){
    switch(direccion){
        case CONVENCION_ARRIBA:
            (*jugador).posicion.fila-=1;
             break;                 
        case CONVENCION_ABAJO:
            (*jugador).posicion.fila+=1;
            break;
        case CONVENCION_DERECHA:
            (*jugador).posicion.columna+=1;
            break;
        case CONVENCION_IZQUIERDA:
            (*jugador).posicion.columna-=1;
            break;
    }

    (*jugador).turnos_restantes -=1;
    if ((*jugador).envenenado)
        (*jugador).turnos_envenenado +=1;
}
/* Se intenta pasar de nivel.
 * Precondiciones: 
 * Postcondiciones: El jugador aparece en la entrada del siguiente nivel
 * o gana dependiendo del nivel, si destruyo el horrocrux del respectivo nivel.
 */

void intentar_pasar_nivel(juego_t* juego){
    if ((*juego).niveles[(*juego).nivel_actual- 1].horrocrux_destruido){
        if ((*juego).nivel_actual==CANTIDAD_NIVELES){
            (*juego).estado= 1;
            return;
        }
        (*juego).nivel_actual+=1;
        (*juego).jugador.posicion=(*juego).niveles[(*juego).nivel_actual- 1].entrada;
    }    
}

void mover_jugador(juego_t *juego, char direccion){
    movimiento_jugador(&(*juego).jugador,direccion);
    if ((*juego).niveles[(*juego).nivel_actual- 1].tiene_guardian)
            interaccion_guardian(&(*juego));
    if ((*juego).jugador.turnos_restantes==0 || (*juego).jugador.turnos_envenenado==TURNOS_MAXIMOS_ENVENEDADO)
            (*juego).estado= -1;
    switch(que_hay((*juego).jugador.posicion,(*juego).niveles[(*juego).nivel_actual- 1])){
    case CONVENCION_OBJETO:
        agarrar_objeto(juego);
        break;
    case CONVENCION_HORROCRUX:
        if (!(*juego).niveles[(*juego).nivel_actual- 1].horrocrux_destruido)
            intentar_romper_horrocrux(&(*juego));
        break;
    case CONVENCION_SALIDA:
        intentar_pasar_nivel(&(*juego));
            break;
    }
}

int estado_juego(juego_t juego){
            return juego.estado;
}

bool puede_moverse_jugador(char movimiento, juego_t juego){
    if (movimiento!=CONVENCION_ARRIBA && movimiento!=CONVENCION_ABAJO && movimiento!=CONVENCION_DERECHA && movimiento!=CONVENCION_IZQUIERDA)
        return false;
    if (movimiento==CONVENCION_ARRIBA && juego.jugador.posicion.fila==0)
        return false;
    if (movimiento==CONVENCION_ABAJO && juego.jugador.posicion.fila==juego.niveles[juego.nivel_actual- 1].filas -1)
        return false;
    if (movimiento==CONVENCION_DERECHA && juego.jugador.posicion.columna==juego.niveles[juego.nivel_actual- 1].columnas-1)
        return false;
    if (movimiento==CONVENCION_IZQUIERDA && juego.jugador.posicion.columna==0)
        return false;
    return true;
}
void mostrar_escenario(char escenario[MAX_FILAS][MAX_COLUMNAS], unsigned int filas, unsigned int columnas){
    system("clear");
    printf("\n");
    for (int i=0;i<filas;i++){
        for (int j=0;j<filas;j++){
            printf("| %c ",escenario[i][j]);
        }
    printf("|\n");
    }
    printf("\n");
}

/* Se actualiza la posicion del basilisco.
 * Precondiciones: El basilisco esta en alguna posicion de su camino.
 * Postcondiciones: El basilisco se mueve dentro de su camino en sentido horario.
 */

void mover_basilisco (nivel_t* nivel,coordenadas_t posiciones[MAX_PERIMETRO],unsigned int* tope){
    int posicion_actual;
    (*tope)=0;
    camino_basilisco(posiciones,&(*tope));
    for(int i=0;i<(*tope);i++){
        if (es_la_misma_posicion((*nivel).guardian.posicion, posiciones[i]))
            posicion_actual=i;
    }
    if (posicion_actual==0)
        (*nivel).guardian.posicion=posiciones[(*tope)-1];
    else
        (*nivel).guardian.posicion=posiciones[posicion_actual-1];
}

/* Se actualiza la posicion de dolores.
 * Precondiciones: Dolores esta en alguna posicion de su camino.
 * Postcondiciones: Dolores se mueve dentro de su camino en sentido horario.
 */

void mover_dolores (nivel_t* nivel,coordenadas_t posiciones[MAX_PERIMETRO],unsigned int* tope){
    int posicion_actual;
    camino_dolores(posiciones,&(*tope),(*nivel));
    for(int i=0;i<(*tope);i++){
        if (es_la_misma_posicion((*nivel).guardian.posicion, posiciones[i]))
        posicion_actual=i;
    }
    if (posicion_actual==0)
        (*nivel).guardian.posicion=posiciones[(*tope)-1];
    else
        (*nivel).guardian.posicion=posiciones[posicion_actual-1];
}

/* Se actualiza la posicion del duende.
 * Precondiciones: El duende esta en alguna posicion de su camino y se inicializo el sentido
 * en el que lo recorre.
 * Postcondiciones: El duende se mueve dentro de su camino en el sentido que deba.
 */

void mover_duende (nivel_t* nivel,coordenadas_t posiciones[MAX_PERIMETRO],unsigned int* tope){
    int posicion_actual;
    camino_duende (posiciones,&(*tope),(*nivel));
    for(int i=0;i<(*tope);i++){
        if (es_la_misma_posicion((*nivel).guardian.posicion, posiciones[i]))
            posicion_actual=i;
    }
    if (posicion_actual==(*tope)-1)
        (*nivel).direccion_duende=CONVENCION_IZQUIERDA_DUENDE;
    if (posicion_actual==0)
        (*nivel).direccion_duende=CONVENCION_DERECHA_DUENDE;
    if ((*nivel).direccion_duende==CONVENCION_IZQUIERDA_DUENDE)
        (*nivel).guardian.posicion=posiciones[posicion_actual-1];
    if ((*nivel).direccion_duende==CONVENCION_DERECHA_DUENDE)
        (*nivel).guardian.posicion=posiciones[posicion_actual+1];
}

void mover_guardian(juego_t *juego){
    coordenadas_t posiciones[MAX_PERIMETRO];
    unsigned int tope=0;
    switch((*juego).niveles[(*juego).nivel_actual- 1].guardian.codigo){
    case CONVENCION_BASILISCO:   
        mover_basilisco(&(*juego).niveles[(*juego).nivel_actual- 1],posiciones,&tope);
        break;
    case CONVENCION_DOLORES:
        mover_dolores(&(*juego).niveles[(*juego).nivel_actual- 1],posiciones,&tope);
        break;
    case CONVENCION_DUENDE:
        mover_duende(&(*juego).niveles[(*juego).nivel_actual- 1],posiciones,&tope);
        break;
    }
    if ((*juego).niveles[(*juego).nivel_actual- 1].tiene_guardian)
        interaccion_guardian(&(*juego));
    if ((*juego).estado!=1)
        if ((*juego).jugador.turnos_restantes==0)
            (*juego).estado= -1;

}


